export type CardType = {
  type: string;
  title: string;
  position: number;
  imgUrl: string;
};
